import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { Client } from "@colyseus/sdk";
import { buildServer } from "../src/server.ts";
import { defaultAppearance, ITEMS } from "@votechor/shared";
import { matchMaker } from "@colyseus/core";

const PORT = 2599;
let srv: ReturnType<typeof buildServer>;
const clients: any[] = [];
const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
async function join(name: string, extra: object = {}) {
  const room = await new Client(`ws://localhost:${PORT}`).joinOrCreate("city", { ...defaultAppearance(), name, ...extra });
  clients.push(room);
  return room;
}
beforeAll(async () => { srv = buildServer(); await srv.server.listen(PORT); });
afterAll(async () => { for (const r of clients) { try { await r.leave(); } catch {} } await srv.server.gracefullyShutdown(false); });

describe("multiplayer server (real WebSocket clients)", () => {
  let a: any, b: any;
  it("first player joins a room with 99 bots", async () => {
    a = await join("Asha");
    await wait(300);
    expect(a.state.real).toBe(1);
    expect(a.state.bots).toBe(99);
    expect(a.state.players.size).toBe(100);
  });
  it("second independent client joins the same room and one bot is dropped", async () => {
    b = await join("Ravi");
    await wait(300);
    expect(b.roomId).toBe(a.roomId);
    expect(a.state.real).toBe(2);
    expect(a.state.bots).toBe(98);
    expect(a.state.players.size).toBe(100);
    expect(a.state.players.get(b.sessionId)?.name).toBe("Ravi");
  });
  it("syncs movement: A sees B move forward", async () => {
    const start = a.state.players.get(b.sessionId).z;
    for (let i = 0; i < 25; i++) { b.send("input", { f: 1, r: 0, yaw: 0, sprint: true, jump: false }); await wait(50); }
    await wait(200);
    expect(a.state.players.get(b.sessionId).z).toBeLessThan(start - 3);
  });
  it("rejects invalid input without crashing or moving the player", async () => {
    const before = a.state.players.get(a.sessionId).x;
    a.send("input", { f: 999, r: "x", yaw: 0, sprint: true, jump: false });
    a.send("input", "garbage");
    await wait(300);
    expect(a.state.players.get(a.sessionId).x).toBeCloseTo(before, 1);
    expect(a.connection.isOpen).toBe(true);
  });
  it("sanitizes unsafe join options (server never trusts the client)", async () => {
    const c = await join("<img onerror=1>", { fac: "god-mode", cap: 99 });
    await wait(400);
    const p = a.state.players.get(c.sessionId);
    expect(p.name).toBe("img onerror1");
    expect(p.fac).toBe("protester");
    await c.leave();
  });
  it("replaces the bot when a player leaves (consented)", async () => {
    await b.leave();
    await wait(400);
    expect(a.state.real).toBe(1);
    expect(a.state.bots).toBe(99);
    expect(a.state.players.size).toBe(100);
  });
  it("police notice a sprinting player, chase, and the server applies health loss", async () => {
    await wait(3500); // spawn protection (3s) expires
    const me = a.state.players.get(a.sessionId);
    let stars = 0, hpMin = 100;
    for (let i = 0; i < 700 && hpMin >= 100; i++) {
      // steer toward the nearest police officer, sprinting
      let best: any = null, bd = Infinity;
      a.state.players.forEach((p: any) => { if (p.fac === "police") { const d = Math.hypot(p.x - me.x, p.z - me.z); if (d < bd) { bd = d; best = p; } } });
      const yaw = Math.atan2(-(best.x - me.x), -(best.z - me.z));
      a.send("input", { f: 1, r: 0, yaw, sprint: true, jump: false });
      await wait(50);
      stars = Math.max(stars, me.stars); hpMin = Math.min(hpMin, me.hp);
    }
    console.log(`police test: max stars=${stars}, min hp=${hpMin}`);
    expect(stars).toBeGreaterThanOrEqual(1);
    expect(hpMin).toBeLessThan(100);
  }, 45000);
  it("server awards an item only when the authoritative position is in range, then respawns it elsewhere", async () => {
    const room: any = matchMaker.getLocalRoomById(a.roomId);
    const rt = room.humans.get(a.sessionId), me = a.state.players.get(a.sessionId);
    const msgs: any[] = []; a.onMessage("pickup", (m: any) => msgs.push(m));
    let [id, it]: [string, any] = [...room.state.items.entries()][0];
    for (const [k, other] of room.state.items) if (k !== id) other.active = false;   // isolate: no incidental pickups
    it.kind = 4; it.x = rt.body.x + 40; it.z = rt.body.z; it.active = true;   // far away: must NOT be collected
    me.hp = 50; await wait(400);
    expect(it.active).toBe(true); expect(msgs.length).toBe(0);
    it.x = rt.body.x + 0.5; it.z = rt.body.z;                                 // in range: server awards it
    for (let i = 0; i < 40 && (it.active || msgs.length === 0); i++) await wait(100);
    expect(it.active).toBe(false); expect(msgs.length).toBe(1);
    expect(msgs[0].name).toBe(ITEMS[4].name);
    expect(a.state.players.get(a.sessionId).hp).toBeGreaterThanOrEqual(95);
    expect(room.respawn.has(id)).toBe(true);
  });
  it("health endpoint responds", async () => {
    const r = await fetch(`http://localhost:${PORT}/health`);
    expect((await r.json()).ok).toBe(true);
  });
});
