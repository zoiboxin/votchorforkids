import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { Client } from "@colyseus/sdk";
import { matchMaker } from "@colyseus/core";
import { buildServer } from "../src/server.ts";
import { ARENA, BALLOT, Phase, STATION_POS, defaultAppearance } from "@votechor/shared";

const PORT = 2596;
let srv: ReturnType<typeof buildServer>, room: any, a: any, b: any;
const clients: any[] = [];
const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
const until = async (f: () => boolean, ms = 12000) => { for (let i = 0; i < ms / 50 && !f(); i++) await wait(50); };
const rt = (c: any) => room.humans.get(c.sessionId);
const put = (c: any, x: number, z: number) => { const r = rt(c); r.body.x = x; r.body.z = z; r.imm = 99; r.hitCd = 99; };  // immune so hazards don't interfere with objective checks
const boss = () => a.state.boss;
beforeAll(async () => {
  srv = buildServer(); await srv.server.listen(PORT);
  const cl = new Client(`ws://localhost:${PORT}`);
  a = await cl.joinOrCreate("city", { ...defaultAppearance(), name: "Asha" }); b = await cl.joinOrCreate("city", { ...defaultAppearance(), name: "Ravi" });
  clients.push(a, b); await wait(400); room = matchMaker.getLocalRoomById(a.roomId);
});
afterAll(async () => { for (const c of clients) { try { await c.leave(); } catch {} } await srv.server.gracefullyShutdown(false); });

describe("boss encounter over the network (two real clients)", () => {
  it("stays idle until players enter the arena, then starts the speech", async () => {
    expect(boss().phase).toBe(Phase.IDLE);
    put(a, ARENA.x, ARENA.z); put(b, ARENA.x + 3, ARENA.z);
    await until(() => boss().phase === Phase.SPEECH);
    expect(boss().phase).toBe(Phase.SPEECH); expect(boss().participants).toBe(2); expect(boss().hp).toBe(100);
  }, 20000);
  it("replicates hazards with a telegraph before they land", async () => {
    await until(() => boss().hazards.size > 0, 6000);
    expect(boss().hazards.size).toBeGreaterThan(0);
    let h: any; boss().hazards.forEach((x: any) => (h = x)); expect(h.t).toBeGreaterThan(0); expect(h.r).toBeGreaterThan(0);
  });
  it("bureaucracy: players sort documents with E (server counts each press)", async () => {
    room.boss.timer = 0.05; await until(() => boss().phase === Phase.BUREAU);
    expect(boss().hp).toBe(80); expect(boss().stations.size).toBe(3);
    room.boss.stations.forEach((s: any) => (s.need = 2));
    put(a, STATION_POS[0].x, STATION_POS[0].z); put(b, STATION_POS[1].x, STATION_POS[1].z);
    for (let i = 0; i < 2; i++) { a.send("interact", {}); b.send("interact", {}); await wait(350); }
    put(a, STATION_POS[2].x, STATION_POS[2].z);
    for (let i = 0; i < 2; i++) { a.send("interact", {}); await wait(350); }
    await until(() => boss().phase === Phase.STAMP);
    expect(boss().phase).toBe(Phase.STAMP); expect(boss().hp).toBe(60);
  }, 20000);
  it("giant stamp: telegraphed shockwaves, then the teamwork phase", async () => {
    await until(() => { let any = false; boss().hazards.forEach((h: any) => { if (h.kind === 1) any = true; }); return any; }, 6000);
    room.boss.stamps = 99; await until(() => boss().phase === Phase.TEAM);
    expect(boss().hp).toBe(40);
  }, 20000);
  it("teamwork: one plate is not enough; two players on two plates complete it", async () => {
    put(a, STATION_POS[0].x, STATION_POS[0].z); put(b, STATION_POS[0].x, STATION_POS[0].z);
    await wait(3800); expect(boss().phase).toBe(Phase.TEAM);
    put(b, STATION_POS[1].x, STATION_POS[1].z);
    await until(() => boss().phase === Phase.VOTE); expect(boss().phase).toBe(Phase.VOTE); expect(boss().hp).toBe(20);
  }, 20000);
  it("final vote: majority needed, shield drops, rewards granted exactly once", async () => {
    put(a, BALLOT.x, BALLOT.z); put(b, BALLOT.x + 1, BALLOT.z);
    a.send("interact", {}); await wait(600);
    expect(boss().phase).toBe(Phase.VOTE);                 // 1 of 2 is below ceil(1.2)=2
    b.send("interact", {});
    await until(() => boss().phase === Phase.WON);
    expect(boss().phase).toBe(Phase.WON); expect(boss().hp).toBe(0);
    await wait(500);
    const sa = a.state.players.get(a.sessionId).support, sb = a.state.players.get(b.sessionId).support;
    expect(sa).toBe(5); expect(sb).toBe(5);
    a.send("interact", {}); b.send("interact", {}); await wait(2500);   // spam after victory
    expect(a.state.players.get(a.sessionId).support).toBe(5); expect(a.state.players.get(b.sessionId).support).toBe(5);
  }, 20000);
  it("is replayable: resets to idle (round 2) and starts again", async () => {
    room.boss.timer = 0.05; await until(() => boss().phase === Phase.IDLE);
    expect(boss().round).toBe(2);
    put(a, ARENA.x, ARENA.z); put(b, ARENA.x + 3, ARENA.z);
    await until(() => boss().phase === Phase.SPEECH);
    expect(boss().phase).toBe(Phase.SPEECH);
  }, 25000);
  it("a player outside the arena cannot advance objectives", async () => {
    room.boss.phase = Phase.VOTE; room.boss.votes.clear();
    put(a, 0, 6); a.send("interact", {}); await wait(500);
    expect(boss().votes).toBe(0);
  });
});
