import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { Client } from "@colyseus/sdk";
import { matchMaker } from "@colyseus/core";
import { buildServer } from "../src/server.ts";
import { defaultAppearance } from "@votechor/shared";

const PORT = 2598;
let srv: ReturnType<typeof buildServer>, a: any, room: any, rt: any;
const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
beforeAll(async () => {
  srv = buildServer(); await srv.server.listen(PORT);
  a = await new Client(`ws://localhost:${PORT}`).joinOrCreate("city", { ...defaultAppearance(), name: "Tester" });
  await wait(400);
  room = matchMaker.getLocalRoomById(a.roomId); rt = room.humans.get(a.sessionId);
});
afterAll(async () => { try { await a.leave(); } catch {} await srv.server.gracefullyShutdown(false); });

describe("creatures (fresh room)", () => {
  it("replicates 14 zombies and 26 animals", () => { expect(a.state.creatures.size).toBe(40); });
  it("a zombie damages an unprotected player and the server sends a hit message", async () => {
    const z = room.creatures.find((c: any) => c.kind === 0), hits: any[] = [];
    a.onMessage("hit", (m: any) => hits.push(m));
    rt.imm = 0; rt.hitCd = 0; rt.body.x = z.x + 3; rt.body.z = z.z;
    for (let i = 0; i < 60 && room.state.players.get(a.sessionId).hp >= 100; i++) await wait(100);
    expect(room.state.players.get(a.sessionId).hp).toBeLessThan(100);
    await wait(200);
    expect(hits.some((h) => /zombie/i.test(h.msg))).toBe(true);
  }, 15000);
  it("zombies ignore a player under spawn protection", async () => {
    const z = room.creatures.find((c: any) => c.kind === 0);
    room.state.players.get(a.sessionId).hp = 100; rt.hitCd = 0; rt.imm = 5; rt.body.x = z.x + 2; rt.body.z = z.z;
    await wait(1500);
    expect(room.state.players.get(a.sessionId).hp).toBe(100);
  });
  it("animals flee from a nearby player", async () => {
    const an = room.creatures.find((c: any) => c.kind > 0);
    rt.imm = 5; rt.body.x = an.x + 4; rt.body.z = an.z;
    const d0 = Math.hypot(rt.body.x - an.x, rt.body.z - an.z);
    await wait(600);
    expect(Math.hypot(rt.body.x - an.x, rt.body.z - an.z)).toBeGreaterThan(d0);
  });
});
