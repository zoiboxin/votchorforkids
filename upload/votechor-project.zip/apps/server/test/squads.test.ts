import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { Client } from "@colyseus/sdk";
import { matchMaker } from "@colyseus/core";
import { buildServer } from "../src/server.ts";
import { defaultAppearance } from "@votechor/shared";

const PORT = 2597;
let srv: ReturnType<typeof buildServer>, room: any;
const rooms: any[] = [];
const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
const until = async (f: () => boolean, ms = 4000) => { for (let i = 0; i < ms / 50 && !f(); i++) await wait(50); };
async function join(name: string) {
  const r: any = await new Client(`ws://localhost:${PORT}`).joinOrCreate("city", { ...defaultAppearance(), name });
  r.notices = []; r.onMessage("notice", (m: any) => r.notices.push(m.msg)); rooms.push(r); return r;
}
beforeAll(async () => { srv = buildServer(); await srv.server.listen(PORT); });
afterAll(async () => { for (const r of rooms) { try { await r.leave(); } catch {} } await srv.server.gracefullyShutdown(false); });

describe("squads and rescue (real clients, fresh room)", () => {
  let a: any, b: any, c: any, code = "";
  const rt = (r: any) => room.humans.get(r.sessionId);
  const st = (r: any) => a.state.players.get(r.sessionId);
  it("players create and join a squad by code", async () => {
    a = await join("Asha"); b = await join("Ravi"); c = await join("Outsider");
    await wait(400); room = matchMaker.getLocalRoomById(a.roomId);
    a.send("squad", { action: "create" });
    await until(() => !!st(a).squad); code = st(a).squad;
    expect(code).toMatch(/^[A-Z2-9]{4}$/);
    b.send("squad", { action: "join", code: code.toLowerCase() });
    await until(() => st(b).squad === code);
    expect(st(b).squad).toBe(code);
    expect(st(c).squad).toBe("");
  });
  it("rejects a bad code without changing anything", async () => {
    c.send("squad", { action: "join", code: "ZZZZ" });
    await until(() => c.notices.length > 0);
    expect(c.notices.at(-1)).toMatch(/No squad/);
    expect(st(c).squad).toBe("");
  });
  it("a squadmate can rescue a detained player in reach, and earns a support point", async () => {
    rt(a).imm = rt(b).imm = 0; rt(b).det = 30; st(b).mode = 1; st(b).hp = 0;
    rt(a).body.x = rt(b).body.x + 2; rt(a).body.z = rt(b).body.z;
    a.send("interact", {});
    await until(() => st(b).mode === 0);
    expect(st(b).mode).toBe(0); expect(rt(b).det).toBe(0);
    expect(st(b).hp).toBe(40); expect(st(a).support).toBe(1);
    expect(b.notices.some((n: string) => /rescued you/.test(n))).toBe(true);
  });
  it("cannot rescue from too far away or if not in the same squad", async () => {
    rt(b).det = 30; st(b).mode = 1; rt(a).actCd = 0;
    rt(a).body.x = rt(b).body.x + 20; rt(a).body.z = rt(b).body.z;
    a.send("interact", {}); await wait(400);
    expect(st(b).mode).toBe(1);                           // too far
    rt(c).actCd = 0; rt(c).imm = 0; rt(c).body.x = rt(b).body.x + 1; rt(c).body.z = rt(b).body.z;
    c.send("interact", {}); await wait(400);
    expect(st(b).mode).toBe(1);                           // not in squad
    expect(st(c).support).toBe(0);
    rt(b).det = 0; st(b).mode = 0;
  });
  it("leaving the squad clears the code", async () => {
    b.send("squad", { action: "leave" });
    await until(() => st(b).squad === "");
    expect(st(b).squad).toBe("");
  });
  it("squads are limited to 4 members", async () => {
    const extra = [await join("E1"), await join("E2"), await join("E3")];
    await wait(300);
    for (const e of extra.slice(0, 2)) { e.send("squad", { action: "join", code }); }
    await until(() => st(extra[1]).squad === code);
    b.send("squad", { action: "join", code }); await until(() => st(b).squad === code);   // a + E1 + E2 + b = 4
    extra[2].send("squad", { action: "join", code });
    await until(() => extra[2].notices.length > 0);
    expect(extra[2].notices.at(-1)).toMatch(/full/);
    expect(st(extra[2]).squad).toBe("");
  });
});
